package rentPack;

public class ResortException extends Exception{
	public ResortException(String message){
		super(message);
	}

}