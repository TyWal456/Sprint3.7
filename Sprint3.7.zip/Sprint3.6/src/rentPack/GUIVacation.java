/*Name: Tyrell Walrond
Course: CSC 243
Instructor: Professor Demarco
Filename: GUIVacation.java
Purpose: The purpose of this file is to contain and construct a Graphical User Interface (GUI)
		class class in order to operate user-friendly display for Victoria's Vacation resort */
		
package rentPack;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import java.util.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

import rentPack.Boat;
import rentPack.Chair;
import rentPack.Umbrella;
import rentPack.ResortException;
import rentPack.rentDriver;
import rentPack.Customer;

public class GUIVacation extends Application {


	private rentDriver display;
	private Scanner input;
	private Rectangle menuBox;
	private GridPane grid;
	private Text menuMessage;
	private ComboBox<String> eqSelection = new ComboBox<>();
	private ComboBox<String> boatMenu = new ComboBox<>();
	private ComboBox<String> chairMenu = new ComboBox<>();
	private ComboBox<String> umbrellaMenu = new ComboBox<>();
	private Spinner<Integer> numRent = new Spinner<>();
	private SpinnerValueFactory<Integer> numbers = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 50, 0);
	private VBox menu = new VBox(10);
	private TextField enterName = new TextField();
	private TextArea enterAddress = new TextArea();
	private TextField enterEmail = new TextField();
	private TextField enterPhone = new TextField();
	private Label selectEq = new Label("Select from the following to Rent: ");
	private Button s1 = new Button("Submit");
	private Button s2 = new Button("Select Equipment");
	private Button c1 = new Button("Choose This Type");
	private Button okNumber = new Button("Submit");
	private Label enterAmount = new Label("Enter the amount: ");
	private Label enterDays = new Label("Enter number of renting days: ");
	private Spinner<Integer> daysRenting = new Spinner<>();
	private SpinnerValueFactory<Integer> days = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 0);
	private Button okDays = new Button("Confirm # of Days");
	private DatePicker date = new DatePicker();
	private Button okDate = new Button("Confirm Date");


	private Button confirm = new Button("Confirm Order");

	private TableView<String> printOrder = new TableView<String>();
	private TableView<String> custInfo = new TableView<String>();

	private Label wrongNum = new Label("Please enter valid phone number with dashes:((###) ###-####)");
	private Label wrongEmail = new Label("Please enter a valid email address:(ex:abc@gmail.com");




	private Button okShip = new Button("Confirm Shipment");
	private ComboBox<String> sites = new ComboBox<>();

	private Boat boatObj = new Boat();
	private Chair chairObj = new Chair();
	private Umbrella umbrellaObj = new Umbrella();

	Label printOut = new Label("Order Print Out:  ( Type |  Equipment Name|   Unit Price|  Qty  |   Rent Days  |  Total Cost | OrderDate  | Venue Choice  )");
	Label custPrint = new Label("Customer Information:  (  Your Name | Email Address  |  Phone  | Mailing Address  ) ");

// Columns for Ordering Data...
	private TableColumn type = new TableColumn();
		//type.setMinWidth(100);
	private TableColumn eqName = new TableColumn();
		//eqName.setMinWidth(100);
	private TableColumn eqPrice = new TableColumn();
		//eqPrice.setMinWidth(100);
	private TableColumn quantity = new TableColumn();
		//quantity.setMinWidth(100);
	private TableColumn rD = new TableColumn();
		//rD.setMinWidth(100);
	private TableColumn total = new TableColumn();
		//total.setMinWidth(150);
	private TableColumn orderDate = new TableColumn();
		//orderDate.setMinWidth(100);
	private TableColumn venueOp = new TableColumn();



	//Columns for Customer Info Data...
	private TableColumn custName = new TableColumn();
	private TableColumn custEmail = new TableColumn();
	private TableColumn custAddress = new TableColumn();
	private TableColumn custPhone = new TableColumn();





	private Boat bInfo = new Boat(boatObj.getEquipType(), boatObj.getEquipName(), boatObj.getPrice(),
			boatObj.getAmount(), boatObj.getRentDays(), boatObj.getTotalCost(),
			boatObj.getDate(), boatObj.getYear());


	private Chair cInfo = new Chair(chairObj.getEquipType(), chairObj.getEquipName(), chairObj.getPrice(),
			chairObj.getAmount(), chairObj.getRentDays(), chairObj.getTotalCost(),
			chairObj.getDate(), chairObj.getYear());

	private Umbrella uInfo = new Umbrella(umbrellaObj.getEquipType(), umbrellaObj.getEquipName(), umbrellaObj.getPrice(),
			umbrellaObj.getAmount(), umbrellaObj.getRentDays(), umbrellaObj.getTotalCost(),
			umbrellaObj.getDate(), umbrellaObj.getYear());

	public static double SALES_TAX = 0.06;
	public static float subTotal, totalCharge;
	



/*function name: GUIVacationMenu
@param: Stage stage
return type: void*/

	public void start(Stage stage) {


		menu.setPadding(new Insets(20, 20, 20, 20));
		numRent.setValueFactory(numbers);
		daysRenting.setValueFactory(days);

		Label menuTitle = new Label("Welcome to Victoria's Resort Rental");
		menuTitle.setMaxWidth(Double.MAX_VALUE);
		menuTitle.setAlignment(Pos.CENTER);

		Label userName = new Label("Enter Full Name: ");
		Label userAddress = new Label("Enter Full Address: ");
		Label userEmail = new Label("Enter Email Address: ");
		Label userPhone = new Label("Enter Phone Number: ");


		Submit submit = new Submit();
		s1.setOnAction(submit);
		SubmitOp submitOp = new SubmitOp();
		s2.setOnAction(submitOp);


		ChooseType choose = new ChooseType();
		c1.setOnAction(choose);

		ConfirmDays rDays = new ConfirmDays();
		okDays.setOnAction(rDays);



		selectEq.setMaxWidth(Double.MAX_VALUE);
		selectEq.setAlignment(Pos.CENTER);

		printOut.setMaxWidth(Double.MAX_VALUE);
		printOut.setAlignment(Pos.CENTER);



		boatMenu.setPromptText("Choose A Boat Type");
		chairMenu.setPromptText("Choose A Chair Type");
		umbrellaMenu.setPromptText("Choose An Umbrella Type");
		eqSelection.setPromptText("Choose Equipment Type");

		eqSelection.getItems().addAll("Boats", "Chairs", "Umbrellas");
		boatMenu.getItems().addAll("Paddle Board", "Single Kyak", "Tandem Kyak", "3-Person Canoe");
		chairMenu.getItems().addAll("Sling Low", "Chaise Lounge", "Folding Classic", "Adirondack");
		umbrellaMenu.getItems().addAll("Chair-Side", "Single", "Family-Size", "Tent");

		sites.setPromptText("Choose Delivery Site");
		sites.getItems().addAll("Victoria's Resort Venue", "Bella's Beach Venue", "Griffin's Grove Venue");

		EnterAmount amount = new EnterAmount();
		okNumber.setOnAction(amount);

		Shipment ship = new Shipment();
		okShip.setOnAction(ship);

		date.setPromptText("Enter Delivery Date:");
		OKDate d = new OKDate();
		okDate.setOnAction(d);

		finishOrder f = new finishOrder();
		confirm.setOnAction(f);


		selectEq.setStyle(
				"-fx-background-color: burlywood;" +
						"-fx-padding: 10 10 10 10;" +
						"-fx-text-color: brown;" +
						"-fx-text-alignment: center;"
		);

		printOut.setStyle(
				"-fx-background-color: burlywood;" +
						"-fx-padding: 10 10 10 10;" +
						"-fx-text-color: brown;" +
						"-fx-text-alignment: center;"
		);


		selectEq.setStyle(
				"-fx-background-color: burlywood;" +
						"-fx-padding: 10 10 10 10;" +
						"-fx-text-color: brown;" +
						"-fx-text-alignment: center;"
		);

		custPrint.setStyle(
				"-fx-background-color: burlywood;" +
						"-fx-padding: 10 10 10 10;" +
						"-fx-text-color: brown;" +
						"-fx-text-alignment: center;"
		);




		enterName.setPrefWidth(25);
		enterAddress.setPrefSize(25, 50);
		enterEmail.setPrefWidth(25);
		enterPhone.setPrefWidth(25);


		menuTitle.setStyle(
				"-fx-text-alignment: center;" +
						"-fx-text-color: brown;" +
						"-fx-background-color: burlywood;" +
						"-fx-padding: 10 10 10 10;"
		);

		userName.setStyle(
				"-fx-text-alignment: center;");

		userAddress.setStyle(
				"-fx-text-alignment: center;");

		userEmail.setStyle(
				"-fx-text-alignment: center;");

		userPhone.setStyle(
				"-fx-text-alignment: center;");










		menu.getChildren().add(menuTitle);
		menu.getChildren().addAll(userName, enterName, userAddress, enterAddress,
				userEmail, enterEmail, userPhone, enterPhone);
		menu.getChildren().add(s1);



		printOrder.setEditable(true);

		type.setMinWidth(150);
		eqName.setMinWidth(150);
		eqPrice.setMinWidth(100);
		quantity.setMinWidth(100);
		rD.setMinWidth(100);
		total.setMinWidth(150);
		orderDate.setMinWidth(100);
		venueOp.setMinWidth(200);

		custAddress.setMinWidth(300);
		custName.setMinWidth(150);
		custEmail.setMinWidth(150);
		custPhone.setMinWidth(150);


		Scene scene = new Scene(menu, 300, 250);

		stage.setTitle("Welcome to Victoria's Resort Menu");
		stage.setScene(scene);
		stage.show();


	}

	class Submit implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			Customer custOrder = new Customer();
			Customer info = new Customer(custOrder.getName(), custOrder.getPhone(), custOrder.getEmail(),
					custOrder.getAddress());

			String expression = "^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$";
			CharSequence inputStr = enterPhone.getText();
			Pattern pattern = Pattern.compile(expression);
			Matcher matcher = pattern.matcher(inputStr);



			String expressionE = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
			CharSequence inputStrE = enterEmail.getText();
//Make the comparison case-insensitive.
			Pattern patternE = Pattern.compile(expressionE,Pattern.CASE_INSENSITIVE);
			Matcher matcherE = pattern.matcher(inputStr);




			custOrder.setName(enterName.getText());

				custOrder.setPhone(enterPhone.getText());
			custOrder.setEmail(enterEmail.getText());
			custOrder.setAddress(enterAddress.getText());


	while(matcher.matches() == false && matcherE.matches() == false) {
		System.out.println("Please enter valid phone number with dashes:((###) ###-####) and or enter a valid email address,ex:abc@gmail.com");
		System.out.println("Please enter a valid email address: (abc@gmail.com)");
		wrongNum.setStyle(
				"-fx-font-color:#ff1205;"+
				"-fx-font-weight:bold;");
		wrongEmail.setStyle("-fx-color:red;"+
				"-fx-font-weight:bold;");
		menu.getChildren().add(wrongEmail);
		menu.getChildren().add(wrongNum);
	}

	menu.getChildren().remove(wrongNum);
	menu.getChildren().remove(wrongEmail);













			custOrder.customer.add(info);
			menu.getChildren().add(selectEq);
			menu.getChildren().addAll(eqSelection, s2);


		}
	}

	class SubmitOp implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {

			if (eqSelection.getValue() == "Boats") {
				boatObj.setEquipType(eqSelection.getValue());
				menu.getChildren().remove(eqSelection);
				menu.getChildren().add(boatMenu);
				menu.getChildren().remove(s2);
				menu.getChildren().add(c1);

			} else if (eqSelection.getValue() == "Chairs") {
				chairObj.setEquipType(eqSelection.getValue());
				menu.getChildren().remove(eqSelection);
				menu.getChildren().add(chairMenu);
				menu.getChildren().remove(s2);
				menu.getChildren().add(c1);
			} else if (eqSelection.getValue() == "Umbrellas") {
				umbrellaObj.setEquipType(eqSelection.getValue());
				menu.getChildren().remove(eqSelection);
				menu.getChildren().add(umbrellaMenu);
				menu.getChildren().remove(s2);
				menu.getChildren().add(c1);
			}


		}
	}


	class ChooseType implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			if (eqSelection.getValue() == "Boats") {
				boatObj.setEquipName(boatMenu.getValue());
				if (boatObj.getEquipName() == "Paddle Board") {
					boatObj.setPrice(65);
				}
				if (boatObj.getEquipName() == "Single Kyak") {
					boatObj.setPrice(45);
				}
				if (boatObj.getEquipName() == "Tandem Kyak") {
					boatObj.setPrice(65);
				}
				if (boatObj.getEquipName() == "3-Person Canoe") {
					boatObj.setPrice(75);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(boatMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);

			} else if (eqSelection.getValue() == "Chairs") {
				chairObj.setEquipName(chairMenu.getValue());
				if (chairObj.getEquipName() == "Sling Low") {
					chairObj.setPrice(5);
				}
				if (chairObj.getEquipName() == "Chaise Lounge") {
					chairObj.setPrice(7);
				}
				if (chairObj.getEquipName() == "Folding Classic") {
					chairObj.setPrice(5);
				}
				if (chairObj.getEquipName() == "Adirondack") {
					chairObj.setPrice(10);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(chairMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);
			} else if (eqSelection.getValue() == "Umbrellas") {
				umbrellaObj.setEquipName(umbrellaMenu.getValue());
				if (umbrellaObj.getEquipName() == "Chair-Side") {
					umbrellaObj.setPrice(5);
				}
				if (umbrellaObj.getEquipName() == "Single") {
					umbrellaObj.setPrice(10);
				}
				if (umbrellaObj.getEquipName() == "Family-Size") {
					umbrellaObj.setPrice(15);
				}
				if (umbrellaObj.getEquipName() == "Tent") {
					umbrellaObj.setPrice(20);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(umbrellaMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);
			}

		}
	}

	class EnterAmount implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {

			if (eqSelection.getValue() == "Boats") {
				boatObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays, daysRenting, okDays);


			} else if (eqSelection.getValue() == "Chairs") {
				chairObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays, daysRenting, okDays);


			} else if (eqSelection.getValue() == "Umbrellas") {
				umbrellaObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays, daysRenting, okDays);

			}

		}
	}

	class ConfirmDays implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {

			if (eqSelection.getValue() == "Boats") {
				boatObj.setRentDays(daysRenting.getValue());
				boatObj.setEquipType(eqSelection.getValue());
				boatObj.setEquipName(boatMenu.getValue());
				menu.getChildren().addAll(sites, okShip);

			} else if (eqSelection.getValue() == "Chairs") {
				chairObj.setRentDays(daysRenting.getValue());
				chairObj.setEquipType(eqSelection.getValue());
				chairObj.setEquipName(chairMenu.getValue());
				menu.getChildren().addAll(sites, okShip);

			} else if (eqSelection.getValue() == "Umbrellas") {
				umbrellaObj.setRentDays(daysRenting.getValue());
				umbrellaObj.setEquipType(eqSelection.getValue());
				umbrellaObj.setEquipName(umbrellaMenu.getValue());
				menu.getChildren().addAll(sites, okShip);
			}
		}
	}

	class Shipment implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {

			menu.getChildren().addAll(date, okDate);
			if (eqSelection.getValue() == "Boats") {
				boatObj.setRentDays(daysRenting.getValue());
				boatObj.setEquipType(eqSelection.getValue());
				boatObj.setEquipName(boatMenu.getValue());
				subTotal = (boatObj.getRentDays() * boatObj.getAmount() * boatObj.getPrice());
				totalCharge = ((float) ((SALES_TAX * subTotal) + subTotal));
				boatObj.setTotalCost(totalCharge);
				if (sites.getValue() == "Victoria's Resort Venue" && daysRenting.getValue() >= 3) {
					totalCharge = (float) (totalCharge - (totalCharge * .10));
					boatObj.setTotalCost(totalCharge);
					boatObj.boats.add(bInfo);
					menu.getChildren().addAll(date, okDate);


				}else  if (sites.getValue() == "Bella's Beach Venue" && daysRenting.getValue() >= 3) {
					totalCharge = (float) (totalCharge - (totalCharge * .10) + 10);
					boatObj.setTotalCost(totalCharge);
					boatObj.boats.add(bInfo);
					menu.getChildren().addAll(date, okDate);


				} else if (sites.getValue() == "Griffin's Grove Venue" && daysRenting.getValue() >= 3) {
					totalCharge = (float) (totalCharge - (totalCharge * .10) + 20);
					boatObj.setTotalCost(totalCharge);
					boatObj.boats.add(bInfo);
					menu.getChildren().addAll(date, okDate);
				}


			} if (eqSelection.getValue() == "Chairs") {
				chairObj.setRentDays(daysRenting.getValue());
				chairObj.setEquipType(eqSelection.getValue());
				chairObj.setEquipName(chairMenu.getValue());
				subTotal = (chairObj.getRentDays() * chairObj.getAmount() * chairObj.getPrice());
				totalCharge = ((float) ((SALES_TAX * subTotal) + subTotal));
				chairObj.setTotalCost(totalCharge);
				menu.getChildren().addAll(date, okDate);


				if (sites.getValue() == "Victoria's Resort Venue" && numRent.getValue() >= 4) {
					totalCharge = (float) (totalCharge - (totalCharge * .10));
					chairObj.setTotalCost(totalCharge);
					chairObj.chairs.add(cInfo);
					menu.getChildren().addAll(date, okDate);

				} else if (sites.getValue() == "Bella's Beach Venue" && numRent.getValue() >= 4) {
					totalCharge = (float) (totalCharge - (totalCharge * .10) + 10);
					chairObj.setTotalCost(totalCharge);
					chairObj.chairs.add(cInfo);
					menu.getChildren().addAll(date, okDate);

				} else if (sites.getValue() == "Griffin's Grove Venue" && numRent.getValue() >= 4) {
					totalCharge = (float) (totalCharge - (totalCharge * .10) + 20);
					chairObj.setTotalCost(totalCharge);
					chairObj.chairs.add(cInfo);
					menu.getChildren().addAll(date, okDate);
				}
			} if (eqSelection.getValue() == "Umbrellas") {
				umbrellaObj.setRentDays(daysRenting.getValue());
				umbrellaObj.setEquipType(eqSelection.getValue());
				umbrellaObj.setEquipName(umbrellaMenu.getValue());
				subTotal = (umbrellaObj.getRentDays() * umbrellaObj.getAmount() * umbrellaObj.getPrice());
				totalCharge = ((float) ((SALES_TAX * subTotal) + subTotal));
				umbrellaObj.setTotalCost(totalCharge);
				if (sites.getValue() == "Victoria's Resort Venue") {
					totalCharge = (float) (totalCharge);
					umbrellaObj.setTotalCost(totalCharge);
					umbrellaObj.umbrellas.add(uInfo);
					menu.getChildren().addAll(date, okDate);

				} else if (sites.getValue() == "Bella's Beach Venue") {
					totalCharge = (float) (totalCharge + 10);
					umbrellaObj.setTotalCost(totalCharge);
					umbrellaObj.umbrellas.add(uInfo);
					menu.getChildren().addAll(date, okDate);

				} else if (sites.getValue() == "Griffin's Grove Venue") {
					totalCharge = (float) (totalCharge + 20);
					umbrellaObj.setTotalCost(totalCharge);
					umbrellaObj.umbrellas.add(uInfo);
					menu.getChildren().addAll(date, okDate);
				}

			}

		}


	}

	class OKDate implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			if (eqSelection.getValue() == "Boats") {
				boatObj.setDate(date.getValue().toString());
				boatObj.boats.add(bInfo);

				for(int i = 0; i < boatObj.boats.size();i++) {
						type.setText(boatObj.boats.get(i).getEquipType());
						eqName.setText(boatObj.boats.get(i).getEquipName());
						eqPrice.setText(String.valueOf(boatObj.boats.get(i).getPrice()));
						quantity.setText(String.valueOf(boatObj.boats.get(i).getAmount()));
						rD.setText(String.valueOf(boatObj.boats.get(i).getRentDays()));
						total.setText(String.valueOf(boatObj.boats.get(i).getTotalCost()));
						orderDate.setText(boatObj.boats.get(i).getDate());
						menu.getChildren().add(printOut);
						venueOp.setText(sites.getValue());

						printOrder.getColumns().addAll(type, eqName, eqPrice, quantity,rD,total,orderDate,venueOp);
						menu.getChildren().add(printOrder);
					menu.getChildren().add(confirm);

				}

			}




			 if (eqSelection.getValue() == "Chairs") {
			 	chairObj.setDate(date.getValue().toString());
			 	chairObj.chairs.add(cInfo);

				 for(int i = 0; i < chairObj.chairs.size();i++) {
					 type.setText(chairObj.chairs.get(i).getEquipType());
					 eqName.setText(chairObj.chairs.get(i).getEquipName());
					 eqPrice.setText(String.valueOf(chairObj.chairs.get(i).getPrice()));
					 quantity.setText(String.valueOf(chairObj.chairs.get(i).getAmount()));
					 rD.setText(String.valueOf(chairObj.chairs.get(i).getRentDays()));
					 total.setText(String.valueOf(chairObj.chairs.get(i).getTotalCost()));
					 orderDate.setText(chairObj.chairs.get(i).getDate());
					 menu.getChildren().add(printOut);
					 venueOp.setText(sites.getValue());

					 printOrder.getColumns().addAll(type, eqName, eqPrice, quantity,rD,total,orderDate,venueOp);
					 menu.getChildren().add(printOrder);
					 menu.getChildren().add(confirm);
				 }



			}
			 if (eqSelection.getValue() == "Umbrellas") {
			 	umbrellaObj.setDate(date.getValue().toString());
			 	umbrellaObj.umbrellas.add(uInfo);

				 for(int i = 0; i < umbrellaObj.umbrellas.size();i++) {
					 type.setText(umbrellaObj.umbrellas.get(i).getEquipType());
					 eqName.setText(umbrellaObj.umbrellas.get(i).getEquipName());
					 eqPrice.setText(String.valueOf(umbrellaObj.umbrellas.get(i).getPrice()));
					 quantity.setText(String.valueOf(umbrellaObj.umbrellas.get(i).getAmount()));
					 rD.setText(String.valueOf(umbrellaObj.umbrellas.get(i).getRentDays()));
					 total.setText(String.valueOf(umbrellaObj.umbrellas.get(i).getTotalCost()));
					 orderDate.setText(umbrellaObj.umbrellas.get(i).getDate());
					 menu.getChildren().add(printOut);
					 venueOp.setText(sites.getValue());


					 printOrder.getColumns().addAll(type, eqName, eqPrice, quantity,rD,total,orderDate,venueOp);
					 menu.getChildren().add(printOrder);
					 menu.getChildren().add(confirm);
				 }






			}
		}
	}


		class finishOrder implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e) {

			custName.setText(enterName.getText());
			custEmail.setText(enterEmail.getText());
			custPhone.setText(enterPhone.getText());
			custAddress.setText(enterAddress.getText());

			custInfo.getColumns().addAll(custName,custEmail, custPhone, custAddress);
			menu.getChildren().add(custPrint);
			menu.getChildren().add(custInfo);

		}

	}
}






