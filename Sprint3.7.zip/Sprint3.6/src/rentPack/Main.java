/*Name: Tyrell Walrond
Course: CSC 243
Instructor: Professor Demarco
Filename: Boat.java
Purpose: The purpose of this file is to contain and construct a boat class for 
		object orientation for a ficticious vacation resort*/
		
package rentPack;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.DatePicker;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;


import rentPack.Boat;
import rentPack.Chair;
import rentPack.Umbrella;
import rentPack.ResortException;
import rentPack.rentDriver;
import rentPack.Customer;

public class Main extends Application{
	
	public static void main(String[] args){
		launch(args);
	}
	
	private rentDriver display;
	private Scanner input;
	private Rectangle menuBox;
	private GridPane grid;
	private Text menuMessage;
	private ComboBox<String> eqSelection = new ComboBox<>();
	private ComboBox<String> boatMenu = new ComboBox<>();
	private ComboBox<String> chairMenu = new ComboBox<>();
	private ComboBox<String> umbrellaMenu = new ComboBox<>();
	private Spinner<Integer> numRent = new Spinner<>();
	private SpinnerValueFactory<Integer> numbers = new SpinnerValueFactory.IntegerSpinnerValueFactory(1,50,0);
	private VBox menu = new VBox(10);
	private TextField enterName = new TextField();
	private TextArea enterAddress = new TextArea();
	private TextField enterEmail = new TextField();
	private TextField enterPhone = new TextField();
	private Button s1 = new Button("Submit");
	private Button s2 = new Button("Select Equipment");
	private Button c1 = new Button("Choose This Type");
	private Button okNumber = new Button("Submit");
	private Label enterAmount = new Label("Enter the amount: ");
	private Label enterDays = new Label("Enter number of renting days: ");
	private Spinner<Integer> daysRenting = new Spinner<>();
	private SpinnerValueFactory<Integer> days = new SpinnerValueFactory.IntegerSpinnerValueFactory(1,100,0);
	private Button okDays = new Button("Confirm # of Days");
	private DatePicker date = new DatePicker();
	private Button okDate = new Button("Confirm Date");
	
	
	private Button okShip = new Button("Confirm Shipment");
	private ComboBox<String> sites = new ComboBox<>();
        
        private Boat boatObj = new Boat();
        private Chair chairObj = new Chair();
        private Umbrella umbrellaObj = new Umbrella();
	private RentObj objCall = new RentObj();

        
               private Boat bInfo = new Boat(boatObj.getEquipType(), boatObj.getEquipName(),boatObj.getPrice(),
                                        boatObj.getAmount(), boatObj.getRentDays(), boatObj.getTotalCost(), 
                                        boatObj.getDate(), boatObj.getYear());
                                
               
               private Chair cInfo = new Chair(chairObj.getEquipType(), chairObj.getEquipName(),chairObj.getPrice(),
                                        chairObj.getAmount(), chairObj.getRentDays(), chairObj.getTotalCost(), 
                                        chairObj.getDate(), chairObj.getYear());
               
               private Umbrella uInfo = new Umbrella(umbrellaObj.getEquipType(), umbrellaObj.getEquipName(),umbrellaObj.getPrice(),
                                        umbrellaObj.getAmount(), umbrellaObj.getRentDays(), umbrellaObj.getTotalCost(), 
                                        umbrellaObj.getDate(), umbrellaObj.getYear());
	
	public static double SALES_TAX = 0.06;
	public static float subTotal,totalCharge;
	



/*function name: mainMenu
@param: Stage stage
return type: void*/
 
public void start(Stage stage){
	
	
	VBox menu = new VBox(10);
	menu.setPadding(new Insets(20, 20, 20, 20));
	numRent.setValueFactory(numbers);
	daysRenting.setValueFactory(days);
	
	Label menuTitle = new Label("Welcome to Victoria's Resort Rental");
	menuTitle.setMaxWidth(Double.MAX_VALUE);
	menuTitle.setAlignment(Pos.CENTER);
	
	Label userName = new Label("Enter Full Name: ");
	Label userAddress = new Label("Enter Full Address: ");
	Label userEmail = new Label("Enter Email Address: ");
	Label userPhone = new Label("Enter Phone Number: ");
	
	

	
	Submit submit = new Submit();
	s1.setOnAction(submit);
	
	SubmitOp submitOp = new SubmitOp();
	s2.setOnAction(submitOp);
	
	
	ChooseType choose = new ChooseType();
	c1.setOnAction(choose);
	
	ConfirmDays rDays = new ConfirmDays();
	okDays.setOnAction(rDays);
	
	
	
	Label selectEq = new Label("Select from the following to Rent: ");
	selectEq.setMaxWidth(Double.MAX_VALUE);
	selectEq.setAlignment(Pos.CENTER);
	
	

	boatMenu.setPromptText("Choose A Boat Type");
	chairMenu.setPromptText("Choose A Chair Type");
	umbrellaMenu.setPromptText("Choose An Umbrella Type");
	eqSelection.setPromptText("Choose Equipment Type");

	eqSelection.getItems().addAll("Boats", "Chairs", "Umbrellas");
	boatMenu.getItems().addAll("Paddle Board", "Single Kyak", "Tandem Kyak", "3-Person Canoe");
	chairMenu.getItems().addAll("Sling Low", "Chaise Lounge", "Folding Classic", "Adirondack");
	umbrellaMenu.getItems().addAll("Chair-Side", "Single", "Family-Size", "Tent");
	
	sites.setPromptText("Choose Delivery Site");
	sites.getItems().addAll("Victoria's Resort Venue", "Bella's Beach Venue", "Griffin's Grove Venue");
	
        EnterAmount amount = new EnterAmount();
        okNumber.setOnAction(amount);
        
	Shipment ship = new Shipment();
	okShip.setOnAction(ship);
	
	date.setPromptText("Enter Delivery Date:");
	OKDate d = new OKDate();
	okDate.setOnAction(d);
	
        
	
	selectEq.setStyle(
	"-fx-background-color: burlywood;"+
	"-fx-padding: 10 10 10 10;" +
	"-fx-text-color: brown;" +
	"-fx-text-alignment: center;"
	);
	
	
	enterName.setPrefWidth(25);
	enterAddress.setPrefSize(25,50);
	enterEmail.setPrefWidth(25);
	enterPhone.setPrefWidth(25);
	

	
	
	menuTitle.setStyle(
                "-fx-text-alignment: center;" +
		"-fx-text-color: brown;" +
                "-fx-background-color: burlywood;" +
                "-fx-padding: 10 10 10 10;"
                );
		
	userName.setStyle(
	"-fx-text-alignment: center;");
	
	userAddress.setStyle(
	"-fx-text-alignment: center;");
	
	userEmail.setStyle(
	"-fx-text-alignment: center;");
	
	userPhone.setStyle(
	"-fx-text-alignment: center;");
	
		
	menu.getChildren().add(menuTitle);
	menu.getChildren().addAll(userName, enterName, userAddress, enterAddress,
				userEmail, enterEmail, userPhone, enterPhone);
	menu.getChildren().add(s1);
	menu.getChildren().add(selectEq);
	menu.getChildren().addAll(eqSelection, s2);
	
	
	Scene scene = new Scene(menu, 300, 250);
	
	stage.setTitle("Welcome to Victoria's Resort Menu");
	stage.setScene(scene);
	stage.show();
	
	
	
	
}

class Submit implements EventHandler<ActionEvent>{
	@Override
	public void handle(ActionEvent e){
		Customer custOrder = new Customer();
		Customer info = new Customer(custOrder.getName(), custOrder.getPhone(), custOrder.getEmail(), 
								custOrder.getAddress());
										
		custOrder.setName(enterName.getText());
		custOrder.setPhone(enterPhone.getText());
		custOrder.setEmail(enterEmail.getText());
		custOrder.setAddress(enterAddress.getText());
		
		custOrder.customer.add(info);
	}
}

class SubmitOp implements EventHandler<ActionEvent>{
	@Override
	public void handle (ActionEvent e){
                
		if(eqSelection.getValue() == "Boats"){
			boatObj.setEquipType(eqSelection.getValue()); 
			menu.getChildren().remove(eqSelection);
			menu.getChildren().add(boatMenu);
			menu.getChildren().remove(s2);
			menu.getChildren().add(c1);
			
		}
		else if(eqSelection.getValue() == "Chairs"){
			chairObj.setEquipType(eqSelection.getValue()); 
			menu.getChildren().remove(eqSelection);
			menu.getChildren().add(chairMenu);
			menu.getChildren().remove(s2);
			menu.getChildren().add(c1);
		}
		
		else if(eqSelection.getValue() == "Umbrellas"){
			umbrellaObj.setEquipType(eqSelection.getValue()); 
			menu.getChildren().remove(eqSelection);
			menu.getChildren().add(umbrellaMenu);
			menu.getChildren().remove(s2);
			menu.getChildren().add(c1);
		}
		
		
	}
}


class ChooseType implements EventHandler<ActionEvent>{
	@Override
		public void handle(ActionEvent e){
			if(eqSelection.getValue() == "Boats"){
				boatObj.setEquipName(boatMenu.getValue());
				if(boatObj.getEquipName() == "Paddle Board"){
					boatObj.setPrice(65);
				}
				if(boatObj.getEquipName() == "Single Kyak"){
					boatObj.setPrice(45);
				}
				if(boatObj.getEquipName() == "Tandem Kyak"){
					boatObj.setPrice(65);
				}
				if(boatObj.getEquipName() == "3-Person Canoe"){
					boatObj.setPrice(75);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(boatMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);
				
			}
			else if(eqSelection.getValue() == "Chairs"){
				chairObj.setEquipName(chairMenu.getValue());
				if(chairObj.getEquipName() == "Sling Low"){
					chairObj.setPrice(5);
				}
				if(chairObj.getEquipName() == "Chaise Lounge"){
					chairObj.setPrice(7);
				}
				if(chairObj.getEquipName() == "Folding Classic"){
					chairObj.setPrice(5);
				}
				if(chairObj.getEquipName() == "Adirondack"){
					chairObj.setPrice(10);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(chairMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);
			}
			else if(eqSelection.getValue() == "Umbrellas"){
				umbrellaObj.setEquipName(umbrellaMenu.getValue());
				if(umbrellaObj.getEquipName() == "Chair-Side"){
					umbrellaObj.setPrice(5);
				}
				if(umbrellaObj.getEquipName() == "Single"){
					umbrellaObj.setPrice(10);
				}
				if(umbrellaObj.getEquipName() == "Family-Size"){
					umbrellaObj.setPrice(15);
				}
				if(umbrellaObj.getEquipName() == "Tent"){
					umbrellaObj.setPrice(20);
				}
				menu.getChildren().remove(c1);
				menu.getChildren().remove(umbrellaMenu);
				menu.getChildren().addAll(enterAmount, numRent);
				menu.getChildren().add(okNumber);
			}

		}
}
                
        class EnterAmount implements EventHandler<ActionEvent>{
        @Override
                public void handle(ActionEvent e){
                        
			if(eqSelection.getValue() == "Boats"){
				boatObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays,daysRenting, okDays);
				
				
			}
			else if(eqSelection.getValue() == "Chairs"){
				chairObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays, daysRenting, okDays);
				
				
			}
			else if(eqSelection.getValue() == "Umbrellas"){
				umbrellaObj.setAmount(numRent.getValue());
				menu.getChildren().remove(enterAmount);
				menu.getChildren().remove(numRent);
				menu.getChildren().remove(okNumber);
				menu.getChildren().addAll(enterDays,daysRenting, okDays);
				
			}
                        
                }
        }
		
	class ConfirmDays implements EventHandler<ActionEvent>{
	@Override
	public void handle(ActionEvent e){
		
		if(eqSelection.getValue() == "Boats"){
			boatObj.setRentDays(daysRenting.getValue());
			boatObj.setEquipType(eqSelection.getValue());
			boatObj.setEquipName(boatMenu.getValue());
			menu.getChildren().addAll(sites, okShip);

		}
		else if(eqSelection.getValue() == "Chairs"){
			chairObj.setRentDays(daysRenting.getValue());
			chairObj.setEquipType(eqSelection.getValue());
			chairObj.setEquipName(chairMenu.getValue());
			menu.getChildren().addAll(sites, okShip);
			
		}
		else if(eqSelection.getValue() == "Umbrellas"){
			umbrellaObj.setRentDays(daysRenting.getValue());
			umbrellaObj.setEquipType(eqSelection.getValue());
			umbrellaObj.setEquipName(umbrellaMenu.getValue());
			menu.getChildren().addAll(sites, okShip);
			}
		}
	}
	
	class Shipment implements EventHandler<ActionEvent>{
	@Override
	public void handle(ActionEvent e){
		
		
		if(eqSelection.getValue() == "Boats"){
			boatObj.setRentDays(daysRenting.getValue());
			boatObj.setEquipType(eqSelection.getValue());
			boatObj.setEquipName(boatMenu.getValue());
			subTotal = (boatObj.getRentDays() * boatObj.getAmount() * boatObj.getPrice());
			totalCharge = ((float)((SALES_TAX * subTotal)+ subTotal));
			boatObj.setTotalCost(totalCharge);
			if(sites.getValue() == "Victoria's Resort Venue" && daysRenting.getValue() >= 3){
				totalCharge = (float)(totalCharge - (totalCharge *.10));
				boatObj.setTotalCost(totalCharge);
				boatObj.boats.add(bInfo);
				menu.getChildren().addAll(date, okDate);
				
		
			}
			else if(sites.getValue() == "Bella's Beach Venue" && daysRenting.getValue() >= 3){
				totalCharge = (float)(totalCharge - (totalCharge *.10) + 10);
				boatObj.setTotalCost(totalCharge);
				boatObj.boats.add(bInfo);
				menu.getChildren().addAll(date,okDate);
				
				
		
			}
			else if(sites.getValue() == "Griffin's Grove Venue" && daysRenting.getValue() >= 3){
				totalCharge = (float)(totalCharge - (totalCharge *.10) + 20);
				boatObj.setTotalCost(totalCharge);
				boatObj.boats.add(bInfo);
				menu.getChildren().addAll(date,okDate);
			}
			
			
		}
		else if(eqSelection.getValue() == "Chairs"){
			chairObj.setRentDays(daysRenting.getValue());
			chairObj.setEquipType(eqSelection.getValue());
			chairObj.setEquipName(chairMenu.getValue());
			subTotal = (chairObj.getRentDays() * chairObj.getAmount() * chairObj.getPrice());
			totalCharge = ((float)((SALES_TAX * subTotal)+ subTotal));
			chairObj.setTotalCost(totalCharge);
			
			
			if(sites.getValue() == "Victoria's Resort Venue" && numRent.getValue() >= 4){
				totalCharge = (float)(totalCharge - (totalCharge *.10));
				chairObj.setTotalCost(totalCharge);
				chairObj.chairs.add(cInfo);
		
			}
			else if(sites.getValue() == "Bella's Beach Venue" && numRent.getValue() >= 4){
				totalCharge = (float)(totalCharge - (totalCharge *.10) + 10);
				chairObj.setTotalCost(totalCharge);
				chairObj.chairs.add(cInfo);
		
			}
			else if(sites.getValue() == "Griffin's Grove Venue" && numRent.getValue() >= 4){
				totalCharge = (float)(totalCharge - (totalCharge *.10) + 20);
				chairObj.setTotalCost(totalCharge);
				chairObj.chairs.add(cInfo);
			}
		}
		else if(eqSelection.getValue() == "Umbrellas"){
			umbrellaObj.setRentDays(daysRenting.getValue());
			umbrellaObj.setEquipType(eqSelection.getValue());
			umbrellaObj.setEquipName(umbrellaMenu.getValue());
			subTotal = (umbrellaObj.getRentDays() * umbrellaObj.getAmount() * umbrellaObj.getPrice());
			totalCharge = ((float)((SALES_TAX * subTotal)+ subTotal));
			umbrellaObj.setTotalCost(totalCharge);
			if(sites.getValue() == "Victoria's Resort Venue"){
				totalCharge = (float)(totalCharge);
				umbrellaObj.setTotalCost(totalCharge);
				umbrellaObj.umbrellas.add(uInfo);
		
			}
			else if(sites.getValue() == "Bella's Beach Venue"){
				totalCharge = (float)(totalCharge+ 10);
				umbrellaObj.setTotalCost(totalCharge);
				umbrellaObj.umbrellas.add(uInfo);
		
			}
			else if(sites.getValue() == "Griffin's Grove Venue"){
				totalCharge = (float)(totalCharge +20);
				umbrellaObj.setTotalCost(totalCharge);
				umbrellaObj.umbrellas.add(uInfo);
			}
			
			}
		
		}


	}
	
	class OKDate implements EventHandler<ActionEvent>{
		@Override
		public void handle(ActionEvent e){
		if(eqSelection.getValue() == "Boats"){
			boatObj.boats.add(bInfo);
			boatObj.setDate(date.getValue().toString());
			for(int i = 0; i < boatObj.boats.size(); i++){System.out.println(
				boatObj.boats.get(i).getEquipType() +','+ boatObj.boats.get(i).getEquipName() +','+ 
				boatObj.boats.get(i).getTotalCost() +','+ boatObj.boats.get(i).getDate());
				}
			}
		}
	}
}


